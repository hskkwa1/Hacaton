import streamlit as st
import openai
import pdfplumber

# Function to extract text from uploaded PDF
def extract_text_from_pdf(pdf_file):
    with pdfplumber.open(pdf_file) as pdf:
        text = ""
        for page in pdf.pages:
            text += page.extract_text()
        return text

# Function to validate text using GPT
def validate_text_with_gpt(api_key, document_text):
    openai.api_key = api_key
    prompt = f"Analyze the following document for errors or inconsistencies: \n\n{document_text}"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=500
    )
    return response['choices'][0]['text']

# Streamlit App
st.title("LLM Data Validator")

# API Key Input
api_key = st.text_input("Enter your OpenAI API Key:", type="password")

# File Uploader
uploaded_file = st.file_uploader("Upload a PDF document for validation", type="pdf")

if uploaded_file and api_key:
    with st.spinner("Extracting text..."):
        document_text = extract_text_from_pdf(uploaded_file)
        st.text_area("Extracted Text:", value=document_text, height=200)

    if st.button("Validate Document"):
        with st.spinner("Validating with GPT..."):
            validation_result = validate_text_with_gpt(api_key, document_text)
            st.subheader("Validation Results")
            st.text(validation_result)
