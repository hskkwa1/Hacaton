function[Blok] = BlokovaMatica(m, n, m1, n1, m2, n2)
clc;
if m < 20 || n < 20
    error("'m' and 'n' must be greater than.. or equal to.. 20!");
end

A = [1,2;2,1];
B = [3,1;2,1];

h = zeros(1,m2);
for i = m2:0
    if i == m2
        h(m2) = randi(floor(exp(3)*5));
    else
        h(m2) = randi(floor(exp(3)*5-h(m2+1)));
    end
end

D = zeros(m2,m2);
D = diag(h);


I = ones(m1);
E = eye(m-m1-m2-m1,n1);

B1 = [B' (zeros(m1,n-m1))];
B2 = [[(zeros(m2,m1)) D]  (zeros(m2,n-m2-m1))];
B3 = [(zeros(m1,n-n1-m1)) [I A]];
B4 = [zeros(m-m1-m2-n1,n-n1) E];

Blok_Transponovany = [[B1' B2'] [B3' B4']];
Blok = Blok_Transponovany';
clc;

end        
