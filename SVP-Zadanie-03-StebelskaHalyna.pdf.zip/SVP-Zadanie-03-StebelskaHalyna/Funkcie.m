function [Ar, As] = Funkcie(a, b, c, d, t, N)

f = @(x) (a * x^2 + b * x + c)^N;
g = @(x) log(x^2) / (d*exp(t*x) + 2);
[C] = Vypocty(N,N,N,N);
Ar = zeros(2*N,N);
As = zeros(N,2*N);

sotchik = 1;
for i = 1:N
    Ar(sotchik,:) =  C(:,i);
    sotchik = sotchik+2;
end
sotchik = 1;
for i = 1:N
    As(:,sotchik) =  C(i,:);
    sotchik = sotchik+2;
end
clear sotchik;

for i = 1:N*2
    for j = 1:N
        if mod(i,2) == 0
            Ar(i,j) = f(Ar(i-1,j));
        end
    end
end

for i = 1:N
    for j = 1:N*2
        if mod(j,2) == 0
            As(i,j) =  g(As(i,j-1));
        end
    end
end
disp('Matrix Ar:')
disp(Ar);
disp('Matirx As:')
disp(As);

nation = @(x) [f(x), g(x)];
fplot(nation, [-1,20]);






