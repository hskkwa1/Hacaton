clear;
clc;
% NahodnaMatica(4,4);
% Funkcie(10, 9, 5, 3, 1, 7)
Vypocty(6,5,2,3);