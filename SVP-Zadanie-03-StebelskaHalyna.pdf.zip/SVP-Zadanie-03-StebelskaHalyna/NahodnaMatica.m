function [A, B] = NahodnaMatica(m, n)

a = -100 + randi(200);
b = -100 + randi(200);

while a >= b 
    a = -100 + randi(200);
    b = -100 + randi(200);
end

A = zeros(m,n);
for k=1:m
    for l=1:n
        A(k,l) = randi ([a b]);
    end
end

disp(['Promizok <' , num2str(a), ';', num2str(b), '> .']);
B = A * A';
disp(A);