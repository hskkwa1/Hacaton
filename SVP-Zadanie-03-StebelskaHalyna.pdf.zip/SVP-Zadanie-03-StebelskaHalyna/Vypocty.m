function [C] = Vypocty (m, n, r1, r2)
clc;
[A, B] = NahodnaMatica(m, n);

disp (['Determinant of a matrix B', num2str(det(B))]);
disp (['Rank of a matrix A', num2str(rank(A))]);
disp (['Rank of a matrix B', num2str(rank(B))]);
disp ('Inverse matrix B^−1 of a matrix B: ');
disp (inv(B));

disp ('Matrix B: ');
disp(B);

for i = 1:size(B, 2)
    tmp = B(r1, i);
    B(r1, i) = B(r2, i);
    B(r2, i) = tmp;
end

for j = 1:size(B, 1)
    tmp = B(j, r1);
    B(j, r1) = B(j, r2);
    B(j, r2) = tmp;
end

C = B;
disp('Matrix C: ');
disp(C);

disp(['Max.rank of  a matrix A: ',num2str(max(A(:)))]);
disp(['Min.rank of  a matrix A: ',num2str(min(A(:)))]);

disp(['The sum of all matrix elements A: ',num2str(sum(A(:)))]);

for i = 1:m
    disp(['The sum of all matrix elements A v ',num2str(i) ,'.line: ',num2str(sum(A(i,:)))]);
end
for i = 1:n
    disp(['The sum of all matrix elements A v ',num2str(i) ,'.column: ',num2str(sum(A(:,i)))]);
end