import com.stebelska.space.Communication;
import com.stebelska.space.Slnecna_sustava;
import com.stebelska.space.Galaxie;
import com.stebelska.space.Vesmir;
import com.stebelska.space.vesmirnetelesa.GulovaHviezdokopa;
import com.stebelska.space.vesmirnetelesa.Planeta;
import com.stebelska.space.vesmirnetelesa.Zem;
import com.stebelska.zive_tvory.Hmyz.Mucha;
import com.stebelska.zive_tvory.Ryby.Kapor;
import com.stebelska.zive_tvory.Ryby.Rudd;
import com.stebelska.zive_tvory.Vtaky.Orol;

import java.util.Date;

public class Main {
    public static void main(String[] args) {

        //Vesmir//
        Communication kanal = new Communication();
        Vesmir First = new Vesmir(true) ;
        First.startVesmir();

        Slnecna_sustava obejects = new Slnecna_sustava("Slnecna_sustava");
        Galaxie Stebelska = new Galaxie("Stebelska",kanal );
        Galaxie Milky_way = new Galaxie("Milky_way", kanal);
        obejects.addTeleso("Hviezda","Sun", 5, 600, 6564);
        obejects.addTeleso("Hviezda","Sirius", 666, 969, 689);
        obejects.addTeleso("Planeta","Mars", 465829,43272,777);
        obejects.addTeleso("Planeta","Venusa", 5559484 , 355841, 855);
        obejects.addTeleso("Planeta","Jupiter", 7175 , 59481, 444);
        obejects.addTeleso("Planeta","Saturn", 84515, 96654, 5848);
        obejects.addTeleso("Planeta","Uran", 95555 , 36854, 91255);
        obejects.addTeleso("Planeta", "Zem", 1488, 65448, 9.81);
        obejects.addTeleso("Kometa","medart", 1939, 1945, 98847);
        obejects.addTeleso("Mesiac","Mesiac", 1789, 58182, 1418);
        obejects.addTeleso("GuľovaHviezdokopa", "GuľovaHviezdokopa", 456, 5678,2135);
        Milky_way.addSustavu(obejects);
        GulovaHviezdokopa stars = new GulovaHviezdokopa("GuľovaHviezdokopa", 456, 5678,2135);
        stars.gula();
        Milky_way.Messenger("Hi, Stebelska!");
        Stebelska.Messenger("Hello, Milky_way!");
        System.out.println(kanal.getSharedString().toString());

        //Zem + tvory//
        Zem MatickaZem= new Zem("Zem",12369, 456987, 5.6 );

        Kapor vianocnykapor = new Kapor(50);
        Date dNow = new Date();
        vianocnykapor.born(dNow);
        MatickaZem.addTvora(vianocnykapor);
        vianocnykapor.move(10,10,0);
        vianocnykapor.dead(dNow);

        Rudd red_eye = new Rudd (30);
        red_eye.born(dNow);
        MatickaZem.addTvora(red_eye);
        red_eye.move(12,12,0);
        red_eye.dead(dNow);

        Orol orlik = new Orol(80);
        orlik.born(dNow);
        MatickaZem.addTvora(orlik);
        orlik.move(14,14,0);
        orlik.dead(dNow);

        Mucha vinnaMuska = new Mucha ();
        vinnaMuska.born(dNow);
        MatickaZem.addTvora(vinnaMuska);
        vinnaMuska.move(20,20,0);
        vinnaMuska.dead(dNow);

        First.stopVesmir();

        }
    }
