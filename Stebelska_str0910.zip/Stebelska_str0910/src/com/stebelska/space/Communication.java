package com.stebelska.space;

public class Communication {
    private StringBuilder posilaucaFunkcia = new StringBuilder();

    public StringBuilder getSharedString() {
        return posilaucaFunkcia;
    }
}
