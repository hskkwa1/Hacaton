package com.stebelska.space;

public class Galaxie {
    private String meno;
    private Slnecna_sustava[] noveSustavy = new Slnecna_sustava [5000000];
    private int counter;
    private Communication hafo;

    public Galaxie(String meno, Communication hafo) {
        this.meno = meno;
        this.hafo = hafo;
    }
    public void Messenger(String message){
        hafo.getSharedString().append("["+ meno +"]"+ message);

    }

    public String getMeno() {
        return meno;
    }

    private void setMeno(String meno) {
        this.meno = meno;
    }

    public int getCounter() {
        return counter;
    }

    private void setSus_counter(int sus_counter) {
        this.counter = sus_counter;
    }
    public void addSustavu (Slnecna_sustava novaSustavy){
        noveSustavy [counter] = novaSustavy;
        counter++;

    }
}
