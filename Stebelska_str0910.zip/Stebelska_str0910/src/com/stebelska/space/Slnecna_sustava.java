package com.stebelska.space;

import com.stebelska.space.vesmirnetelesa.*;

public class Slnecna_sustava {
    private final Vesmirne_teleso[] subjects = new Vesmirne_teleso[5000000];
    private int objectCounter;
    private String NameOfSubject;

    public Slnecna_sustava(String nameOfSubject) {
        NameOfSubject = nameOfSubject;
        setObjectCounter(0);
    }
        public void addTeleso(String type, String name, int value_1, double value_2, double value_3) {
            while (objectCounter < subjects.length) {
                if (type.equals("Hviezda")) {
                    subjects[objectCounter] = new Hviezda(name, value_1, value_2, value_3);
                    objectCounter++;
                } else if (type.equals("Planeta")) {
                    subjects[objectCounter] = new Planeta(name, value_1, value_2, value_3);
                    objectCounter++;
                } else if (type.equals("Kometa")) {
                    subjects[objectCounter] = new Kometa(name, value_1, value_2, value_3);
                    objectCounter++;
                } else if (type.equals("Mesiac")) {
                    subjects[objectCounter] = new Mesiac(name, value_1, value_2, value_3);
                    objectCounter++;
                } else if (type.equals("GuľovaHviezdokopa")) {
                    subjects[objectCounter] = new GulovaHviezdokopa(name, value_1, value_2, value_3);
                    objectCounter++;
                } else {
                    System.out.println("Invalid celestial body type");
                    break;
                }
                break;
            }
        }

    public int getObjectCounter() {
        return objectCounter;
    }

    private void setObjectCounter(int objectCounter) {
        this.objectCounter = objectCounter;
    }

    public String getNameOfSubject() {
        return NameOfSubject;
    }

    private void setNameOfSubject(String nameOfSubject) {
        NameOfSubject = nameOfSubject;
    }
}
