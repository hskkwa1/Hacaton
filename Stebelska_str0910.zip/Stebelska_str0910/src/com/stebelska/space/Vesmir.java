package com.stebelska.space;

public class Vesmir {

        private boolean state;
        private long size;
        private long decrisedSize;

        public Vesmir(boolean state) {
            this.state = false;
            this.size = 0;
            this.decrisedSize = size;

        }

        public void startVesmir(){
            System.out.println("Turn on Vesmir");
            increaseSize();
        }

        public void stopVesmir(){
            decreaseSize(size);
            this.state = false;
            System.out.println("Turn off Vesmir");
        }

        public void increaseSize(){
            while (size < 2000){
                size += 500;
                System.out.println("The size of my Vsemir is... "+ size +" square km. ");
            }

        }

        public void decreaseSize(long desiredSize){
            while (desiredSize > 1000){
                desiredSize -= 250;
                System.out.println("The size of my Vsemir is..."+ desiredSize +" cubic km.");
            }
        }
    }


