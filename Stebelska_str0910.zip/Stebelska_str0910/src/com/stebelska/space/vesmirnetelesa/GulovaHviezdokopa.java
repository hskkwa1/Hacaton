package com.stebelska.space.vesmirnetelesa;

public class GulovaHviezdokopa extends Vesmirne_teleso{
    private String name;
    private int age;
    private double size;
    private double distance;

    public GulovaHviezdokopa(String name, int age, double size, double distance) {

        this.age = age;
        this.size = size;
        this.distance = distance;
    }
    public  void gula(){
        System.out.println("Hi, I am Global cluster a globular cluster of stars with a large and precisely \n" +
                " symmetrical concentration of stars towards its center ");
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    private void setAge(int age) {
        this.age = age;
    }

    public double getSize() {
        return size;
    }

    private void setSize(double size) {
        this.size = size;
    }

    public double getDistance() {
        return distance;
    }

    private void setDistance(double distance) {
        this.distance = distance;
    }
}

