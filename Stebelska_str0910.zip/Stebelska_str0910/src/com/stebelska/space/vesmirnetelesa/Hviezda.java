package com.stebelska.space.vesmirnetelesa;

public class Hviezda extends Vesmirne_teleso{
    private String name;
    private int age;
    private double size;
    private double temperature;

    public Hviezda(String name, int age, double size, double temperature) {
        this.name = name;
        this.age = age;
        this.size = size;
        this.temperature = temperature;
    }

    public double getTemperature() {
        return temperature;
    }

    private void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    private void setAge(int age) {
        this.age = age;
    }

    public double getSize() {
        return size;
    }

    private void setSize(double size) {
        this.size = size;
    }
}
