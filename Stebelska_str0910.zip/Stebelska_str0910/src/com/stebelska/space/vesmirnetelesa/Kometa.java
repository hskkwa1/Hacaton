package com.stebelska.space.vesmirnetelesa;

public class Kometa extends Vesmirne_teleso{
    private int size;
    private double temperature;
    private String name;

    private double sizeOfTheTail;


    public Kometa(String name, int size, double temperature, double sizeOfTheTail) {
        this.size = size;
        this.temperature = temperature;
        this.name = name;
        this.sizeOfTheTail = sizeOfTheTail;
    }
    public int getSize() {
        return size;
    }

    private void setSize(int size) {
        this.size = size;
    }

    public double getTemperature() {
        return temperature;
    }

    private void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public String getType() {
        return name;
    }

    public void setType(String name) {
        this.name = name;
    }

    public double getSizeOfTheTail() {
        return sizeOfTheTail;
    }

    public void setSizeOfTheTail(double sizeOfTheTail) {
        this.sizeOfTheTail = sizeOfTheTail;
    }
}
