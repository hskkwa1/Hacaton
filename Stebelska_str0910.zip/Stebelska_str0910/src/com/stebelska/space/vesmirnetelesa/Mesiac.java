package com.stebelska.space.vesmirnetelesa;

public class Mesiac extends Vesmirne_teleso {
    private String name;
    private double radius;
    private double mass;
    private int temperature;

    public Mesiac(String name, int temperature, double radius, double mass) {
        this.radius = radius;
        this.mass = mass;
        this.temperature = temperature;
        this.name = name;
    }

    public double getRadius() {
        return radius;
    }

    private void setRadius(double radius) {
        this.radius = radius;
    }

    public double getMass() {
        return mass;
    }

    private void setMass(double mass) {
        this.mass = mass;
    }

    public int getTemperature() {
        return temperature;
    }
  
    private void setTemperature(int temperature) {
        this.temperature = temperature;
    }
}
