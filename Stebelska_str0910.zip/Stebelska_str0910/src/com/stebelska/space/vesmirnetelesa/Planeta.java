package com.stebelska.space.vesmirnetelesa;

public class Planeta extends Vesmirne_teleso{
    private String Name;
    private int age;
    private double masa;
    private double number;

    public Planeta(String name, int age, double masa, double number) {
        Name = name;
        this.age = age;
        this.masa = masa;
        this.number = number;
    }
    public String getName() {
        return Name;
    }

    private void setName(String name) {
        Name = name;
    }

    public int getAge() {
        return age;
    }

    private void setAge(int age) {
        this.age = age;
    }

    public double getMasa() {
        return masa;
    }

    private void setMasa(double masa) {
        this.masa = masa;
    }

    public double getNumber() {
        return number;
    }

    private void setNumber(double number) {
        this.number = number;
    }
}
