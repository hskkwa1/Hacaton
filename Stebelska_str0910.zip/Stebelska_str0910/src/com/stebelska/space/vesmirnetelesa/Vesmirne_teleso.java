package com.stebelska.space.vesmirnetelesa;

public class Vesmirne_teleso {

        private String type;

        public String getType() {
            return type;
        }

        protected void setType(String type) {
            this.type = type;
        }
}

