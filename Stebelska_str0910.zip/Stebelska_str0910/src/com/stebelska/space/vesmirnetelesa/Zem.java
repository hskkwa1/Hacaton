package com.stebelska.space.vesmirnetelesa;

import com.stebelska.zive_tvory.Tvor;

public class Zem extends Planeta {
    private Tvor[] poleTvorov;
    private int pocet_tvorov;

    public Zem(String name, int age, double masa, double number) {
        super(name, age, masa, number);
        poleTvorov = new Tvor[65923125];
        pocet_tvorov = 0;

    }

    public void addTvora(Tvor tentotvor) {
        for (int a = 0; a < 2000; a++) {
            poleTvorov[pocet_tvorov] = tentotvor;
            pocet_tvorov++;
        }
    }
}



