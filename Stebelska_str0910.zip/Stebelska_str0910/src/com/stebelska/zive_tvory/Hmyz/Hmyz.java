package com.stebelska.zive_tvory.Hmyz;

import com.stebelska.zive_tvory.sustavovce_diely.Bezstavovce;

public abstract class Hmyz extends Bezstavovce {
}
