package com.stebelska.zive_tvory.Hmyz;

public class Mucha extends Hmyz {
    public Mucha() {
    }
}
