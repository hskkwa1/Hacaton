package com.stebelska.zive_tvory.Ryby;

import java.util.Date;

public class Kapor extends Ryba {
    public Kapor(int pocet_stavcov) {
        super(pocet_stavcov);
    }
}
