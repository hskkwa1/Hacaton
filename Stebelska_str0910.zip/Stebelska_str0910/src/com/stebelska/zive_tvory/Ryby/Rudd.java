package com.stebelska.zive_tvory.Ryby;

public class Rudd extends Ryba {
    public Rudd(int pocet_stavcov) {
        super(pocet_stavcov);
    }
}
