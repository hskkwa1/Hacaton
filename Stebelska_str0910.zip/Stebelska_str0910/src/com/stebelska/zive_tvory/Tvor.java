package com.stebelska.zive_tvory;
import  java.util.Date;
public abstract class Tvor  implements  bornable, deadable{
    protected Date dayOfBirth;
    protected Date dayOfDeath;

    public  abstract void move (int direction_x,int direction_y,int direction_z);

    public Date getDayOfBirth() {
        return dayOfBirth;
    }
}
