package com.stebelska.zive_tvory.Vtaky;

public class Orol extends Vtak{
    public Orol(int pocet_stavcov) {
        super(pocet_stavcov);
    }
}
