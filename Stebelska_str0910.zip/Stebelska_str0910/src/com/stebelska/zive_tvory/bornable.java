package com.stebelska.zive_tvory;
import  java.util.Date;
public interface bornable {
    public void born( Date dayOfBirth);

}

