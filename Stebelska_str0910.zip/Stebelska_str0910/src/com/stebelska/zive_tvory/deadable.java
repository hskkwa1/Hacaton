package com.stebelska.zive_tvory;
import  java.util.Date;
public interface deadable {
    public void dead( Date dayOfDeath);
}
