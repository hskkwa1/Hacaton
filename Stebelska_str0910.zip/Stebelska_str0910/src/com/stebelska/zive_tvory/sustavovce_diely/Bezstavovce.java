package com.stebelska.zive_tvory.sustavovce_diely;

import com.stebelska.zive_tvory.Tvor;

import java.util.Date;

public abstract class Bezstavovce extends Tvor {
    public Bezstavovce() {
    }

    @Override
    public void move(int direction_x, int direction_y, int direction_z) {

    }

    @Override
    public void born(Date dayOfBirth) {

    }

    @Override
    public void dead(Date dayOfDeath) {

    }
}

