package com.stebelska.zive_tvory.sustavovce_diely;
public class Chrbtica {
    private Stavec[] stavce;

    public Chrbtica(int pocet_stavcov) {
        stavce = new Stavec[pocet_stavcov];
        for(int i= 0; i<pocet_stavcov; i++){
            stavce[i] = new Stavec();
        }

    }
}
