package com.stebelska.zive_tvory.sustavovce_diely;

public class Stavec {
}
