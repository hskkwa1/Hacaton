package com.stebelska.zive_tvory.sustavovce_diely;

import com.stebelska.zive_tvory.Tvor;

public abstract class Stavovec extends Tvor {
     protected Chrbtica chrbtica;
     protected Sustava[] sustavy;

     public Stavovec(int pocet_stavcov) {
          chrbtica = new Chrbtica(pocet_stavcov);
     }
    private void  create_sustavy(){
         sustavy = new Sustava[8];

         sustavy[0]= new Sustava(Typ_sustavy.OBEHOVA);
         sustavy[1]= new Sustava(Typ_sustavy.OPORNA);
         sustavy[2]= new Sustava(Typ_sustavy.DYCHACIA);
         sustavy[3]= new Sustava(Typ_sustavy.VYLUCOVACIA);
         sustavy[4]= new Sustava(Typ_sustavy.POHYBOVA);
         sustavy[5]= new Sustava(Typ_sustavy.TRAVIACA);
         sustavy[6]= new Sustava(Typ_sustavy.ROZMNOZOVACIA);
         sustavy[7]= new Sustava(Typ_sustavy.NERVOVA);

    }

     public Chrbtica getChrbtica() {
          return chrbtica;
     }

     public Sustava[] getSustavy() {
          return sustavy;
     }
}
