package com.stebelska.zive_tvory.sustavovce_diely;

public class Sustava {
    Typ_sustavy typSustavy;

    public Sustava(Typ_sustavy typSustavy) {
        this.typSustavy = typSustavy;
    }

    public Typ_sustavy getTypSustavy() {
        return typSustavy;
    }
}
