package com.stebelska.zive_tvory.sustavovce_diely;

public enum Typ_sustavy {
    OPORNA,
    OBEHOVA,
    VYLUCOVACIA,
    POHYBOVA,
    DYCHACIA,
    TRAVIACA,
    ROZMNOZOVACIA,
    NERVOVA



}
